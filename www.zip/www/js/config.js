angular.module('config', [])

.constant('API_URL', 'https://www.nuvemlogistica.com.br:3000');
